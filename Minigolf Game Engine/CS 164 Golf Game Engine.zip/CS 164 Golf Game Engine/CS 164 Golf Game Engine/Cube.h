#pragma once

#include "engine\Actor3D.h"

class Cube : public Actor3D
{
public:
	Cube();
	~Cube();
};

